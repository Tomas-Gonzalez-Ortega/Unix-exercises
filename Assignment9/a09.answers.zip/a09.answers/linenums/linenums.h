//
//  linenums.h
//  linenums
//
//  Created by Tom Nuss on 2018-03-29.
//  Copyright © 2018 Tomas Gonzalez. All rights reserved.
//

#ifndef linenums_h
#define linenums_h

int main(int argc, const char * argv[]);

#endif /* linenums_h */
