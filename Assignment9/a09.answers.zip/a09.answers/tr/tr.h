//
//  tr.h
//  tr
//
//  Created by Tom Nuss on 2018-03-30.
//  Copyright © 2018 Tomas Gonzalez. All rights reserved.
//

#ifndef tr_h
#define tr_h

int main(int argc, char** argv);

#endif /* tr_h */
