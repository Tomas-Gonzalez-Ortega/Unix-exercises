//
//  rev.h
//  rev
//
//  Created by Tom Nuss on 2018-03-30.
//  Copyright © 2018 Tomas Gonzalez. All rights reserved.
//

#ifndef rev_h
#define rev_h

int main(int argc, const char * argv[]);
#endif /* rev_h */
